import java.util.Scanner;

class Carrinho {
  public void Compras() {
    int opcao;
    double p1 = 49.90;
    double p2 = 59.90;
    double p3 = 89.90;
    double p4 = 69.90;
    double p5 = 99.90;
    double p6 = 49.90;
    Scanner input = new Scanner(System.in);
      System.out.println("Digite a ID do produto: ");
      int id = input.nextInt();

      System.out.println("Quantidade: ");
      int qtd = input.nextInt();
      

    if (id == 1234) {
      System.out.println("Sabonete facial antiacne adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total1 = qtd*p1;
        System.out.println("Valor total: R$"  + total1);
          System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.printf("Compra finalizada com sucesso");
          }
    }
    else if(id == 5678) {
      System.out.println("Hidratante facial adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total2 = qtd*p2;
        System.out.println("Valor total: R$"  + total2);
      System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.printf("Compra finalizada com sucesso");
          }
    } 
    else if (id == 9876) {
      System.out.println("Sérum facial de Vitamina C adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total3 = qtd*p3;
        System.out.println("Valor total: R$"  + total3);
      System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.printf("Compra finalizada com sucesso");
          }
    }
    else if (id == 5432) {
      System.out.println("Protetor solar facial adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total4 = qtd*p4;
        System.out.println("Valor total: R$"  + total4);
      System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.printf("Compra finalizada com sucesso");
          }
    }
    else if (id == 7410) {
      System.out.println("Creme facial clareador adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total5 = qtd*p5;
        System.out.println("Valor total: R$"  + total5);
      System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.printf("Compra finalizada com sucesso");
          }
    }
    else if (id == 8520) {
      System.out.println("Cleasing oil de camomila adicionado ao carrinho.");
        System.out.println("Quantidade: "+qtd);
        double total6 = qtd*p6;
        System.out.println("Valor total: R$"  + total6);
      System.out.println("Deseja adicionar mais produtos ao carrinho?");
          System.out.println("1 - Sim");
          System.out.println("2 - Não");
          opcao = input.nextInt();
          if (opcao == 1) {
            Compras();
          } else if (opcao == 2) {
            System.out.println("Compra finalizada com sucesso");
          }
    }
  }
}

    