import java.util.Scanner;
class Usuario {
  public void Cadastro() {
     String nome;
     String endereco;
     String email;
     int senha;
     Scanner input = new Scanner(System.in);

     System.out.println("Nome: ");
     nome = input.nextLine();

     System.out.println("Endereço: ");
     endereco = input.nextLine();

     System.out.println("E-mail: ");
     email = input.nextLine();

     System.out.println("Senha: ");
     senha = input.nextInt();

     System.out.println("Cadastro efetuado com sucesso!");
    
  }
  public void Login() {
    String email;
    int senha;
    Scanner input = new Scanner(System.in);

    System.out.println("Digite o e-mail cadastrado: ");
    email = input.nextLine();

    System.out.println("Digite sua senha: ");
    senha = input.nextInt();
    System.out.println("\nBem-vindo!");
    System.out.println("3 - Acessar catálogo de produtos");  
    System.out.println("4 - Acessar carrinho de compras");  
    int opcao = input.nextInt();
    if (opcao == 3) {
      Produto lista = new Produto();
      lista.Catalogo();
    }else if (opcao == 4) {
      Carrinho acesso = new Carrinho();
      acesso.Compras();
    }
      

  }
}