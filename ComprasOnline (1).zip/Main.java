import java.util.Scanner;

public class Main {
  public static void main (String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Bem-vindo!");
    System.out.println("Escolha uma das opções abaixo:");
    System.out.println("1 - Realizar cadastro");
    System.out.println("2 - Logar");
    System.out.println("3 - Visualizar catálogo de produtos");
     System.out.println("4 - Adicionar produto ao carrinho de compras");
    System.out.println("Escolha a opção desejada: ");

    int opcao = input.nextInt();
      if (opcao == 1) {
        Usuario novo = new Usuario();
        novo.Cadastro();
    } else if (opcao == 2) {
        Usuario novo = new Usuario();
        novo.Login();
    } else if (opcao == 3) {
        Produto lista = new Produto();
        lista.Catalogo();
    } else if (opcao == 4) {
        Carrinho compra = new Carrinho();
        compra.Compras();
    }
    
  }
}