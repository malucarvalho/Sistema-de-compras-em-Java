
public class Produto {
  public void Catalogo() {
    String p1 = "\nSabonete facial antiacne\nDescrição: Sabonete facial ideal para peles acneicas e oleosas.\nValor: R$49,90\nID: 1234\n";
    
    String p2 = "Hidratante facial\nDescrição: Hidratante facial para todos os tipos de pele.\nValor: R$59,90\nID: 5678\n";
    
    String p3 = "Sérum facial de Vitamina C\nDescrição: Sérum antioxidante de uso diurno e noturno\nValor: R$ 89,90\nID: 9876\n";
    
    String p4 = "Protetor solar facial\nDescrição: Protetor solar facial FPS 70, protege durante até 5 horas\nValor: R$69,90\nID: 5432\n";
    
    String p5 = "Creme facial clareador\nDescrição: Creme facial clareador de manchas acneicas.\nValor: R$99,90\nID: 7410\n";
    
    String p6 = "Cleasing oil de camomila\nDescrição: Removedor de maquiagem a base de óleo de camomila\nValor: R$ 49,90\nID: 8520\n";

    System.out.println(p1);
    System.out.println(p2);
    System.out.println(p3);
    System.out.println(p4);
    System.out.println(p5);
    System.out.println(p6);
  
  
    
    }
  }
  